Event Binding
Event Binding lets our application listen for and respond to user actions such as 
Mouse click, Mouse move ,etc.
To bind an event , we use event binding syntax which consist of targetEventName within () on
left hand side and methodName on right hand side as shown below :

<button (click) = "showStudents()"> Show Students </button>